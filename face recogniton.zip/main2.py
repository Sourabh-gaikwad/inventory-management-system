import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime

path = 'Training_images'
images = []
classNames = []
myList = os.listdir(path)
print(myList)
for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])
print(classNames)


def findEncodings(images):
    encodeList = []

    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList





encodeListKnown = findEncodings(images)
print('Encoding Complete')

cap = cv2.VideoCapture(0)
#cap = cv2.VideoCapture('http://192.0.0.4:8080/video')

present_students={}


import mysql.connector

def insert_into_database(name):
        try:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="123456",
                database="adi"
            )

            mycursor = mydb.cursor()

            sql = "INSERT INTO Attendance (name, in_time) VALUES (%s, %s)"
            val = (name, datetime.now())

            mycursor.execute(sql, val)

            mydb.commit()
            print("Record inserted successfully")
        except mysql.connector.Error as err:
            print("Error:", err)


def update_out_time(name, out_time):
        try:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="123456",
                database="adi"
            )

            mycursor = mydb.cursor()

            sql = "UPDATE Attendance SET out_time = %s WHERE name = %s AND out_time IS NULL"
            val = (out_time, name)

            mycursor.execute(sql, val)

            mydb.commit()
            print("Out time updated successfully")
        except mysql.connector.Error as err:
            print("Error:", err)




while True:
    success, img = cap.read()
    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    facesCurFrame = face_recognition.face_locations(imgS)
    encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

    for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

        print("matches",matches)
        #matches [True, False, True]

        print("faceDis",faceDis)
        #faceDis [0.35322364 0.71054379 0.55977503]

        print("faceLoc", faceLoc)
        #faceLoc (41, 93, 84, 50)

        matchIndex = np.argmin(faceDis)


        if matches[matchIndex] and any(faceDis < 0.45):
            name = classNames[matchIndex].upper()
        else:
            name = "Unknown"

        y1, x2, y2, x1 = faceLoc
        y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.rectangle(img, (x1, y2-35), (x2, y2), (0, 255, 0), cv2.FILLED)

        
        if name != "Unknown":
            if name not in present_students:
                present_students[name] = {'entered': False, 'in_time': None, 'out_time': None}
                cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                if present_students[name]['entered']==False:
                    present_students[name]['entered']=True
                    present_students[name]['in_time']=datetime.now()
                    cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                    insert_into_database(name) 
            else:
                if (datetime.now() - present_students[name]['in_time']).total_seconds() > 30:
                    if present_students[name]['out_time']==None:
                       out_time=present_students[name]['out_time']=datetime.now()
                       update_out_time(name,out_time)



            cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
        else:
            cv2.putText(img, "Unknown", (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)

            
                

    cv2.imshow('Webcam', img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
