from flask import Flask, render_template, request
#Flask is a web framework that allows developers to build lightweight web applications quickly and easily with Flask Libraries.

""""
This line imports the Flask class and two functions, render_template and request, from the Flask module.
Flask is the main class of the Flask web framework that you use to create web applications.
render_template is a function used to render HTML templates. It takes the name of a template file as an argument 
and returns the rendered HTML content.
request is an object that represents the HTTP request made by the client to the server. It allows you to access data 
submitted via forms, query parameters, headers, etc."""


app = Flask(__name__)

#app = Flask(__name__): This line creates a Flask application object named app. The __name__ variable is a special variable in Python that 
#represents the name of the current module. When you run the script directly (as the main program), __name__ is set to '__main__'. 
#Passing __name__ as an argument to Flask() is a common pattern in Flask applications to tell the Flask instance where to find templates, 
#static files, and other resources.

#app = Flask(__name__, static_url_path='/static')


@app.route('/')
def index():
    return render_template('index.html')
"""
This line is a decorator that associates the function below it (index()) with a specific URL route ('/').
When a client sends an HTTP request to the root URL of the application (e.g., http://example.com/), 
Flask will invoke the decorated function (index()) to handle the request."""


"""
In Flask, @app.route('/') is a Python decorator used to associate a URL route with a specific function.

Here's what it means:

@app.route('/'): This line is a decorator applied to a function in your Flask application. 
Decorators are a way to modify the behavior of functions in Python.

('/'): Inside the parentheses, you specify the URL route that you want to associate with the function. 
In this case, '/' represents the root URL of your Flask application. It means that whenever a client accesses the root URL 
(e.g., http://example.com/), Flask will execute the function that follows this decorator."""



@app.route('/submit', methods=['POST'])
def submit():
    # Handle the click event here
    Stu_name = request.form['input_name']
    rollno = request.form['rollno']
    PRN = request.form['PRN']
    class_name = request.form['class']
    
    # Print the input data
    print("Name:", Stu_name)
    print("Roll No:", rollno)
    print("PRN:", PRN)
    print("Class:", class_name)
    
    import mysql.connector


    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456",
        database="adi"
    )

    mycursor = mydb.cursor()
    #mydb.cursor(): This method is called on the MySQL database connection object mydb. It returns a cursor object that allows you 
    #to interact with the database by executing SQL queries, fetching results, and managing transactions.

    # Execute SELECT query
    mycursor.execute("SELECT * FROM Student_Info")
    result = mycursor.fetchall()

    mycursor.execute("SELECT COUNT(*) FROM Student_Info WHERE Roll_No = %s", (rollno,))
    result = mycursor.fetchone()
    print(result)
    #(1,)
    # If the primary key value already exists, return error message
    if result[0] > 0:
        return render_template('index.html', error_message=f"Error: Record with the same Roll NO => {rollno} already exists. Please recheck your Roll No & Try again")

    mycursor.execute("SELECT COUNT(*) FROM Student_Info WHERE PRN = %s", (PRN,))
    result1 = mycursor.fetchone()
    print(result1)
    #(1,)
    # If the primary key value already exists, return error message
    if result1[0] > 0:
        return render_template('index.html', error_message=f"Error: Record with the same PRN NO => {PRN} already exists. Please recheck your Roll No & Try again")

    """
    error_message=: This is a keyword argument in a function call. It indicates that the value on the right side of the = sign will 
    be assigned to the parameter named error_message.

    f": The letter 'f' preceding the opening double quote indicates that this is an f-string.
    """
    """
    You prefix the string with an f or F.
    Inside the string, you can place expressions within curly braces {}. These expressions will be evaluated at runtime, 
    and their results will be inserted into the string."""

    import cv2
    import os


    # Initialize the webcam
    cap = cv2.VideoCapture(0)
    """
    cap = cv2.VideoCapture(0): This line creates a VideoCapture object named cap, which is used to access the webcam. The argument 0 
    indicates the index of the webcam device to be opened. 0 typically represents the default webcam device on the system. If you 
    have multiple cameras, you can specify a different index to access a specific camera."""

    face_classifier = cv2.CascadeClassifier("C:/Users/adity/OneDrive/Desktop/Face Recongnition/haarcascade_frontalface_default.xml")
    """
    cv2.CascadeClassifier: This is a class provided by OpenCV for object detection using Haar feature-based cascade classifiers.

    "C:/Users/adity/OneDrive/Desktop/Face Recongnition/haarcascade_frontalface_default.xml": This is the path to the XML file that 
    contains the trained model for detecting frontal faces. This XML file contains the parameters and weights of the Haar cascade 
    classifier trained specifically for frontal face detection.

    When you create the face_classifier object with this XML file path, you're essentially loading the pre-trained face detection model into 
    memory. Later, you'll use this face_classifier object to detect faces in images or video frames captured from a webcam or a video file."""
    
    # Check if the webcam is opened successfully
    if not cap.isOpened():
        print("Error: Could not open webcam")
        exit()

    """
    if not cap.isOpened():: This if statement checks whether the cap object (the webcam) is successfully opened or not. The isOpened()
      method returns True if the webcam is opened successfully and False otherwise.

    print("Error: Could not open webcam"): If the webcam fails to open (i.e., if cap.isOpened() returns False), this line prints an 
    error message indicating that the webcam could not be opened.

    exit(): The exit() function terminates the program. If the webcam fails to open, the program exits after printing the error message."""


   

    # Create the "Training_images" folder if it doesn't exist
    folder_path = 'Training_images'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)


    while True:
        # Capture frame-by-frame
        success, image = cap.read()
        """
        sucess, image = cap.read(): This line reads a image from the video capture object cap. It returns two values: success, which is a boolean 
        indicating whether the frame/image is successfully read, and frame/image, which is the actual frame data."""


         # Detect faces in the frame
        faces = face_classifier.detectMultiScale(image, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        print("faces",faces)
        #[[99, 526, 420, 205]]

        """
        face_classifier: This is an object that represents a pre-trained model used to detect faces in images.

        detectMultiScale: This is a function provided by OpenCV that is used to detect objects (in this case, faces) at multiple scales in an
          image. The "MultiScale" part means it can detect objects of different sizes within the image.

        image: This is the image in which faces are to be detected. It's the frame captured from the webcam.

        scaleFactor=1.1: This parameter specifies how much the image size is reduced at each image scale. A smaller scale factor means the 
        image is reduced less, allowing smaller objects (like faces) to be detected.

        minNeighbors=5: This parameter specifies how many neighbors each candidate rectangle should have to retain it. It helps to filter out 
        false positives by requiring a certain number of overlapping detections before considering a region as a face.

        minSize=(30, 30): This parameter specifies the minimum size of the detected object. It helps to filter out noise by ignoring regions 
        that are smaller than this minimum size, assuming they're not actual faces."""

        """
        Parameters:

        scaleFactor: Imagine you're looking at the picture from far away first, then gradually zooming in. This parameter controls how much you 
        zoom in each time. A smaller value means you zoom in more, which allows you to detect smaller faces, but it also takes more time.
        minNeighbors: This is about how many nearby areas also need to look like faces for an area to be considered a face. If you set it high, 
        it's more likely that only clear, obvious faces will be detected.
        minSize: This sets the smallest size a face can be. If something is smaller than this, it's probably not a face, so we ignore it."""

        """
        The parameters scaleFactor, minNeighbors, and minSize control the sensitivity and accuracy of the face detection algorithm."""
        # Draw rectangles around the faces
        for (x, y, w, h) in faces:
            cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)

        """
        for (x, y, w, h) in faces:: This loop iterates over each rectangle (face) detected in the frame. Each rectangle is represented by its 
        top-left corner coordinates (x, y) and its width (w) and height (h).
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2): This line draws a rectangle around each detected face on the original frame 
        (image). It uses the OpenCV function cv2.rectangle() to draw the rectangle. The rectangle's coordinates are determined by the top-left 
        corner (x, y) and the bottom-right corner (x+w, y+h). The color of the rectangle is specified as (255, 0, 0), which represents blue in 
        the BGR color format. The last argument 2 specifies the thickness of the rectangle's border."""

            # Display the captured frame with face rectangles
        cv2.imshow('Capture Frame', image)

        """
        cv2.imshow(): This is a function from the OpenCV library used to display an image in a window.
        'Capture Frame': This is the title of the window where the image will be displayed. It's the name you'll see at the top of the window.
        image: This is the image data that you want to display. In this case, it's the captured frame from the webcam.
        """


        faceregion = None  # Initialize faceregion with None before the if block

        #The "face region" refers to the portion of an image where a human face is detected.
        #(ROI)Region of Interest refers to a specific area or subset of an image that is selected for further analysis or processing.


        # Wait for the 's' key to be pressed to capture the image
        if cv2.waitKey(1) & 0xFF == ord('s'):
            
            if len(faces) > 0:
                """
                len(faces): This returns the number of detected faces in the current frame.
                > 0: This checks if there is at least one face detected."""
                # Extract the first face ROI
                (x, y, w, h) = faces[0]
                """
                faces[0]: This accesses the first detected face in the faces list.
                (x, y, w, h): This unpacks the coordinates and dimensions of the bounding box of the first detected face into individual variables x, y, w, and h."""
                faceregion = image[y:y+h, x:x+w]
                print("faceregion",faceregion)


            if faceregion is not None:
                # Save the captured image in the "Training_images" folder
                image_path = os.path.join(folder_path, f'{PRN}.jpg')
                cv2.imwrite(image_path, faceregion)
                print(f"Image captured and saved as {image_path}")

            
  
        
            """
            cv2.waitKey(1): This function waits for a keyboard event for a specified duration (1 millisecond in this case). It returns 
            the ASCII value of the key pressed, or -1 if no key is pressed during the specified time.
            & 0xFF: This bitwise AND operation with 0xFF is used to extract the least significant 8 bits (or 1 byte) of the key pressed, 
            which ensures compatibility with different operating systems.
            ord('s'): This function returns the ASCII value of the character 's'."""
            
               # Insert data into table
            mycursor.execute("INSERT INTO Student_Info (Stu_name, Roll_no, PRN, Class) VALUES (%s, %s, %s, %s)", (Stu_name, rollno, PRN, class_name))
            mydb.commit()


            break

    # Release the webcam and close OpenCV windows
    cap.release()
    cv2.destroyAllWindows()
    return '', 204
    """
    return: This keyword is used to exit the current function and return a value (or values) to the caller.
    '', 204: In this case, the function is returning an empty string ('') and an HTTP status code 204.
    In HTTP, a status code of 204 means "No Content". It indicates that the server successfully processed the request, but there is no content to
    return in the response body. This status code is typically used for requests where the server does not need to send any additional data back to the client, such as in cases where the request was a success but there is no need to return any data."""

if __name__ == '__main__':
    app.run(debug=True)

"""
if __name__ == '__main__':: This line checks if the script is being run directly by the Python interpreter (i.e., not imported as a module 
in another script).
app.run(debug=True): This line starts the Flask web application. It tells Flask to run the application with debugging enabled (debug=True).
 Debug mode provides useful error messages and automatic reloading of the application when changes are made to the code, which is helpful
during development.
So, when this block of code is executed, Flask will start running the web application with debugging enabled if the script is being run
 directly by the Python interpreter. This allows you to test and develop the Flask application locally"""




















"""@app.route('/Take_image')
def take_images():
    import cv2
    import os

    import mysql.connector


    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456",
        database="adi"
    )

    mycursor = mydb.cursor()


    # Initialize the webcam
    cap = cv2.VideoCapture(0)

    # Check if the webcam is opened successfully
    if not cap.isOpened():
        print("Error: Could not open webcam")
        exit()

    # Create the "aditya" folder if it doesn't exist
    folder_path = 'Training_images'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # Counter to keep track of captured images

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        # Display the captured frame
        cv2.imshow('Capture Frame', frame)

        # Wait for the 's' key to be pressed to capture the image
        if cv2.waitKey(1) & 0xFF == ord('s'):
            # Increment the image counter

            # Save the captured image in the "aditya" folder
            image_path = os.path.join(folder_path, f'{Stu_name}.jpg')
            cv2.imwrite(image_path, frame)

            

            sql = f"UPDATE Student_Info SET image = %s WHERE name = '{student}' AND out_time IS NULL"
            val = (image_path,)

            mycursor.execute(sql, val)
            print(f"Image captured and saved as {image_path}")

        # Break the loop if 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close OpenCV windows
    cap.release()
    cv2.destroyAllWindows()
    return '', 204

if __name__ == '__main__':
    app.run(debug=True)"""
