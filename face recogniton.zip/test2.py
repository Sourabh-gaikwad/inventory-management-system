import cv2
#openCV is a opensource library which is used for face Recogntion,AI,ML
#It allows us read,write and manipulate(handling and controlling) images and videos.
#used for image and video processing

import numpy as np
#Numpy is python library that provides mathmatical function that operates on array metrices of numerical data.

import face_recognition
#It is used for face detection, face recognition and facial feature extractions.

import os
#used for interacting with os

from datetime import datetime
#handling data and time operations

path = 'Training_images' 
#'Training_images' is a folder
#This string represents directory(folder) path where the training images are located.


images = []
#we have create empty list with name images.
#used to store images read from directory(folder) specified by the path variable


StudentNames = []
#we have create empty list with name StudentNames.

myList = os.listdir(path)
#os.listdir() fuction to obtain(get) a list of file names, present in the directory(folder) where we specified by the path variable

print(myList)
#This line prinits the list of filesnames
#output=['Aakash.jpg', 'Sanket.jpg']

for image in myList:
    curImg = cv2.imread(f'{path}/{image}')
    images.append(curImg)
    StudentNames.append(os.path.splitext(image)[0])

#This loop iterates through each file in myList. It reads each image using cv2.imread(image read), then appends it to the images list. 
#It also extracts the Student name (without file extension) using os.path.splitext and appends it to the StudentNames list.

print("StudentNames",StudentNames)
#Output= StudentNames ['Aakash', 'Sanket']


print("Images",images)
"""
Images [array([[[200, 218, 229],
        [202, 220, 231],
        [203, 221, 232],
        ...,
        [246, 240, 233],
        [246, 240, 233],
        [246, 240, 233]],

       [[201, 219, 230],
        [202, 220, 231],
        [203, 221, 232],
        ...,
        [246, 240, 233],
        [246, 240, 233],
        [246, 240, 233]],

       [[201, 219, 230],
        [202, 220, 231],
        [203, 221, 232],
        ...,
        [246, 240, 233],
        [246, 240, 233],
        [246, 240, 233]],

       ...,

       [[208, 207, 197],
        [208, 207, 197],
        [208, 207, 197],
        ...,
        [214, 213, 203],
        [214, 213, 203],
        [214, 213, 203]],

       [[207, 206, 196],
        [207, 206, 196],
        [208, 207, 197],
        ...,
        [214, 213, 203],
        [214, 213, 203],
        [214, 213, 203]],

       [[207, 206, 196],
        [207, 206, 196],
        [207, 206, 196],
        ...,
        [214, 213, 203],
        [214, 213, 203],
        [214, 213, 203]]], dtype=uint8), array([[[213, 225, 227],

        [213, 225, 227],
        [213, 225, 227],
        ...,
        [208, 220, 222],
        [209, 221, 223],
        [209, 221, 223]],

       [[213, 225, 227],
        [213, 225, 227],
        [213, 225, 227],
        ...,
        [209, 221, 223],
        [209, 221, 223],
        [209, 221, 223]],

       [[213, 225, 227],
        [213, 225, 227],
        [213, 225, 227],
        ...,
        [209, 221, 223],
        [209, 221, 223],
        [209, 221, 223]],

       ...,

       [[207, 219, 221],
        [207, 219, 221],
        [207, 219, 221],
        ...,
        [202, 217, 219],
        [202, 217, 219],
        [203, 218, 220]],

       [[206, 218, 220],
        [207, 219, 221],
        [207, 219, 221],
        ...,
        [202, 217, 219],
        [202, 217, 219],
        [203, 218, 220]],

       [[207, 219, 221],
        [207, 219, 221],
        [208, 220, 222],
        ...,
        [201, 216, 218],
        [202, 217, 219],
        [203, 218, 220]]], dtype=uint8)]
"""

def findEncodings(images):
    encodeList = []

    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList

"""
This function findEncodings takes a list of images as input and returns a list of encodings for each face detected in the images. 
It converts each image to RGB"""



encodeListKnown = findEncodings(images)
#This line calls the findEncodings function to encode all the training images and stores the encodings in encodeListKnown.
#encoding means converting information from one form to another so that it can be easily stored, transmitted, or understood by computers.
print('Encoding Complete')
#print a message that indicates encoding is completed.

print("encodeListKnown",encodeListKnown)

"""The face_encodings() function gives you a list of numbers that describe the unique features of a person's face in an image. 
Each number represents something specific about the face, like the shape of the eyes, nose, or mouth. 
These numbers are calculated by the computer based on the image it sees.

and 

face_recognition often returns face encodings as lists of 128 floating-point numbers.
"""
"""
encodeListKnown [array([-1.88975915e-01,  2.99598873e-02,  6.04173131e-02,  2.25130599e-02,
        1.48809105e-02, -3.66579406e-02,  1.39938593e-02, -1.02885224e-01,
        1.08019903e-01, -1.50870653e-02,  2.73476541e-01,  7.52565265e-03,
       -1.98893264e-01, -2.10738793e-01,  5.80048561e-02,  1.27031073e-01,
       -1.01870283e-01, -1.55737728e-01, -4.04208153e-02, -7.25967735e-02,
        7.75327832e-02, -1.99113041e-02,  7.03331679e-02,  3.38445902e-02,
       -2.31702760e-01, -2.82115161e-01, -7.12600648e-02, -1.39612600e-01,
        1.28973722e-02, -7.61255771e-02, -2.71311551e-02,  9.96301323e-02,
       -1.73043817e-01, -2.23230198e-02,  3.14527899e-02,  1.33483216e-01,
        4.67476621e-02, -2.91860849e-03,  2.08211780e-01, -6.19705059e-02,
       -1.97263956e-01, -4.07797061e-02,  5.11145294e-02,  2.13593036e-01,
        1.17517181e-01, -1.04987174e-02,  2.67680846e-02,  2.22753733e-05,
        8.43469203e-02, -2.30515718e-01,  5.51923364e-02,  1.11719377e-01,
        1.38946816e-01,  2.80564111e-02,  9.06718895e-02, -1.34688511e-01,
        2.13390831e-02,  6.54990673e-02, -1.87360451e-01,  3.23819667e-02,
       -3.60223576e-02, -9.77065414e-02, -3.87970731e-02, -5.14653604e-03,
        1.79702163e-01,  1.34809121e-01, -1.11115858e-01, -1.02363840e-01,
        1.21488661e-01, -7.56011754e-02, -1.20193996e-02,  1.74324766e-01,
       -1.32035986e-01, -2.09382981e-01, -2.81118035e-01,  7.65825063e-02,
        4.33856219e-01,  7.62410909e-02, -2.47311905e-01,  4.71527204e-02,
       -2.59163473e-02, -2.11579725e-02,  9.73896757e-02,  7.74602443e-02,
       -7.15394840e-02,  6.91073164e-02, -1.53124958e-01,  4.51834723e-02,
        1.68813735e-01, -1.50228627e-02, -5.72885647e-02,  1.67617083e-01,
        9.29476321e-03,  9.33749974e-02,  6.29082173e-02,  8.95960629e-02,
       -6.93772361e-03, -9.87942610e-03, -7.98736960e-02, -1.16120586e-02,
        1.13441445e-01, -3.24746110e-02,  8.04469176e-03,  7.05630630e-02,
       -8.94322842e-02,  8.27514827e-02,  1.37339141e-02, -1.59947127e-02,
       -4.18039262e-02,  3.92127112e-02, -3.87846977e-02, -2.73003373e-02,
        3.49657163e-02, -2.83043861e-01,  1.77969575e-01,  1.42450348e-01,
       -9.87713933e-02,  1.34085491e-01,  2.50890329e-02,  7.45402426e-02,
       -1.38736367e-02, -1.34212915e-02, -8.52896124e-02, -6.89880699e-02,
        1.04508504e-01, -2.64591910e-02,  8.31624120e-02, -5.51010855e-03]), 
        
        array([-0.10878181,  0.13645463,  0.10164022, -0.01831735, -0.03206028, 
        0.01314078, -0.10657662, -0.07131741,  0.16047831, -0.10709053,
        0.1072654 ,  0.00851384, -0.17057727, -0.0404678 , -0.11201772,
        0.12181997, -0.11789531, -0.1595324 , -0.11896281, -0.13480237,
        0.00624102,  0.0739934 , -0.01915282,  0.01960296, -0.24534011,
       -0.2782352 , -0.07128599, -0.13737978, -0.03671944, -0.09639419,
       -0.03656311, -0.03824343, -0.13844636,  0.02342032, -0.02776877,
        0.06822876,  0.06510264,  0.02902713,  0.11872038,  0.01803755,
       -0.14816988,  0.04573354,  0.08519495,  0.24305473,  0.1485045 ,
        0.10028759,  0.04927156, -0.04247753,  0.08860466, -0.20004521,
        0.07996984,  0.13725865,  0.06836379,  0.06062675,  0.10633035,
       -0.12484246, -0.03575423,  0.07215074, -0.12992732,  0.07844149,
        0.03979488,  0.02665996, -0.09989673,  0.02253341,  0.21669976,
        0.14833449, -0.14116806, -0.11965673,  0.16934326, -0.21938421,
       -0.04628746,  0.02379211, -0.05280953, -0.0895194 , -0.2940788 ,
        0.08115239,  0.47771645,  0.14244376, -0.15618908,  0.03162567,
       -0.07532877, -0.01057674,  0.02164974,  0.03852648, -0.19245771,
        0.05726545, -0.05580715,  0.06554683,  0.17956567,  0.08171875,
       -0.00713571,  0.13201694,  0.04380828,  0.00582705,  0.00655418,
        0.07051317, -0.15051612, -0.04529141, -0.04531051,  0.009131  ,
        0.09379072, -0.007774  ,  0.01706496,  0.12990008, -0.12400943,
        0.15494989, -0.03612429, -0.07359917, -0.00494026,  0.21411924,
       -0.09968444, -0.10093048,  0.15363303, -0.19020826,  0.08385887,
        0.14612728, -0.02925881,  0.09774219,  0.09347926,  0.13308346,
       -0.00935812,  0.08591272, -0.10903864, -0.14665559,  0.00488919,
       -0.09888767,  0.08489438,  0.06211429])]"""


cap = cv2.VideoCapture(0)
#cap = cv2.VideoCapture('http://192.168.106.152:8080/video')

#This initializes the video capture object. It can either capture video from the webcam (0) or from a specified URL.


while True:
    success, img = cap.read()
    print("succ",success)
    print("succ",img)
    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    """
    This while loop continuously captures frames from the video stream.
    cap.read() reads a frame from the video capture object cap, and success indicates whether the frame was successfully read.
    img contains the captured frame.
    The captured frame is resized to a smaller size (1/4 of the original) using cv2.resize().
    The resized frame is converted from BGR to RGB color space using cv2.cvtColor().


    (0, 0): These numbers represent the desired output size of the image. In this case, (0, 0) means that the size of 
    the output image will be automatically determined based on the scaling factors provided next.

    None: This parameter specifies the interpolation method to be used for resizing. 
    Here, None means that the default interpolation method will be used.

    0.25, 0.25: These numbers are the scaling factors for resizing the image. 
    They indicate that the output image will be 25% of the size of the original image, both in width and height.


    Output=
    sucess, True
    img[[[100 101  98]
        [ 95  95  92]
        [ 94  92  90]
        ...
        [110 111 115]
        [111 112 117]
        [111 112 117]]
 
    imgs [[[ 55  55  55]
    [ 51  51  51]
    [ 52  57  55]
    ...
    [126 138 189]
    [118 146 220]
    [248 254 255]]

    [[ 66  67  59]
    [ 67  69  52]
    [ 70  72  50]

    """

    facesCurFrame = face_recognition.face_locations(imgS)
    encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

    print("facesCurFrame",facesCurFrame)

    """
    facesCurFrame [(36, 112, 79, 69)]"""

    """
    These lines use the face_recognition library to detect faces in the current frame (imgS).
    face_recognition.face_locations() returns the locations of faces in the frame as a list of tuples 
    containing coordinates of the top-left and bottom-right corners of the face bounding box.
    face_recognition.face_encodings() computes the face encodings for each face detected in the frame.

    (Coordinates refer to a set of values that represent the position or 
    location of a point or object in a two-dimensional or three-dimensional space)
    """

    for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
        """
        This line initiates a loop to iterate over pairs of elements from two lists simultaneously.
        encodesCurFrame contains the face encodings of the faces detected in the current frame.
        facesCurFrame contains the locations (bounding box coordinates) of the faces detected in the current frame.
        zip() is used to iterate over both lists simultaneously."""
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

        #faceLoc (41, 93, 84, 50)

        """
        Inside the loop, this line compares the current face encoding encodeFace with a list of known face encodings encodeListKnown.
        face_recognition.compare_faces() returns a list of boolean values indicating whether the current face encoding 
        matches any of the known face encodings.
        matches will contain a boolean value for each known face encoding, indicating whether there's a match with the 
        current face encoding.
                
        This line calculates the face distance between the current face encoding encodeFace and all the known face encodings 
        in encodeListKnown.
        face_recognition.face_distance() returns an array of distances between the current face encoding and 
        each of the known face encodings.
        The lower the distance, the more similar the faces are."""

        

        print("matches",matches)
        #matches [True, False, True]

        print("faceDis",faceDis)
        #faceDis [0.35322364 0.71054379 0.55977503]

        matchIndex = np.argmin(faceDis)
        """
        This line calculates the index of the smallest value in the array faceDis, which represents the distances
        between the current face encoding and each of the known face encodings.
        np.argmin() from the NumPy library is used to find the index of the minimum value in an array.
        """
        print("matchIndex",matchIndex)
        #matchIndex 1

        if matches[matchIndex] and any(faceDis < 0.4):
            name = StudentNames[matchIndex].upper()
        else:
            name = "Unknown"

        """
        any() is used as a function that takes an iterable (faceDis) and returns True if any element of faceDis is less than 0.4."""
        """
        Given matches = [True, False, True] and matchIndex = 0:
        matches[0] is True.
        So, the condition if matches[matchIndex]: evaluates to True."""

        y1, x2, y2, x1 = faceLoc
        print("1",y1,x2,y2,x1)
        #1 55 129 107 78
        """"
        This line unpacks the coordinates of the bounding box of the detected face.
        faceLoc is a tuple containing four values representing the top-left (y1, x1) and 
        bottom-right (y2, x2) coordinates of the bounding box."""

        y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
        print("2",y1,x2,y2,x1)
        #2 220 516 428 312
        """
        This line scales up the coordinates of the bounding box by a factor of 4.
        It multiplies each coordinate (y1, x2, y2, x1) by 4 to increase the size of the bounding box."""

        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        """
        This line draws a rectangle around the detected face on the image (img).
        It uses cv2.rectangle() function to draw the rectangle.
        The rectangle's top-left corner coordinates are (x1, y1) and the bottom-right corner coordinates are (x2, y2).
        (0, 255, 0) specifies the color of the rectangle in BGR format. Here, it's green.
        2 is the thickness of the rectangle's border."""


        cv2.rectangle(img, (x1, y2-35), (x2, y2), (0, 255, 0), cv2.FILLED)
        """
        This line draws a filled rectangle below the main rectangle to write text.
        It uses cv2.rectangle() function with cv2.FILLED flag, which fills the rectangle with the specified color.
        The top-left corner coordinates of the filled rectangle are (x1, y2-35) and the bottom-right corner coordinates are (x2, y2).
        (0, 255, 0) specifies the color of the filled rectangle, which is green."""
        
        cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
        """
        This line writes text on the image to display the name of the detected individual.
        It uses cv2.putText() function to write text.
        name contains the name of the detected individual.
        (x1 + 6, y2 - 6) specifies the coordinates of the bottom-left corner of the text.
        cv2.FONT_HERSHEY_COMPLEX specifies the font type.
        1 is the font scale (size).
        (255, 255, 255) specifies the color of the text in BGR format. Here, it's white.
        2 is the thickness of the text stroke."""

    cv2.imshow('Webcam', img)
    """
    This line displays the processed image (img) in a window with the title "Webcam".
    It uses cv2.imshow() function to display the image.
    The first argument is the title of the window.
    The second argument is the image to be displayed"""
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    #ASCII stands for "American Standard Code for Information Interchange." 
    #It's a character encoding standard used for representing text characters in computers and other devices that use text.
    """
    This line waits for a key press for 1 millisecond using cv2.waitKey(1).
    The key pressed is then compared to the ASCII value of 'q' (ord('q')), which represents the letter 'q'.
    If the pressed key is 'q', the condition becomes True, and the loop breaks using the break statement."""

cap.release()

"""
This line releases the video capture object (cap).
It frees up the resources associated with the webcam or video file being captured.
This is important to release the webcam or video file so that it can be used by other applications or processes."""
cv2.destroyAllWindows()

"""
This line closes all the OpenCV windows created.
It's important to close the windows to release the system resources associated with them after the processing is done."""