from flask import Flask, render_template, request
import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime
import mysql.connector

app = Flask(__name__)

mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456",
        database="adi"
    )

mycursor = mydb.cursor()

mycursor.execute("SELECT COUNT(*) FROM Student_Info")
count = mycursor.fetchone()[0]
#(3,)

@app.route('/')
def index():
    return render_template('index.html', message=count)


@app.route('/submit', methods=['POST'])
def submit():
    # Handle the click event here
    Stu_name = request.form['input_name']
    rollno = request.form['rollno']
    PRN = request.form['PRN']
    class_name = request.form['class']
    
    # Print the input data
    print("Name:", Stu_name)
    print("Roll No:", rollno)
    print("PRN:", PRN)
    print("Class:", class_name)
      

    # Execute SELECT query
    mycursor.execute("SELECT * FROM Student_Info")
    result = mycursor.fetchall()

    mycursor.execute("SELECT COUNT(*) FROM Student_Info WHERE Roll_No = %s", (rollno,))
    result = mycursor.fetchone()
    #(1,)

    if result[0] > 0:
        return render_template('index.html', error_message=f"Error: Record with the same Roll NO => {rollno} already exists. Please recheck your Roll No & Try again")

    mycursor.execute("SELECT COUNT(*) FROM Student_Info WHERE PRN = %s", (PRN,))
    result1 = mycursor.fetchone()
    print(result1)
  
    if result1[0] > 0:
        return render_template('index.html', error_message=f"Error: Record with the same PRN NO => {PRN} already exists. Please recheck your Roll No & Try again")


    # Initialize the webcam
    cap = cv2.VideoCapture(0)

    face_classifier = cv2.CascadeClassifier("C:/Users/adity/OneDrive/Desktop/Face Recongnition/haarcascade_frontalface_default.xml")
    
    #Xml file contains the pretrained model for detecting frontal face

     
    if not cap.isOpened():
        print("Error: Could not open webcam")
        exit()


    # Create the "Training_images" folder if it doesn't exist
    folder_path = 'Training_images'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # Counter to keep track of captured images

    while True:
        # Capture frame-by-frame
        ret, image = cap.read()

        # Detect faces in the frame
        faces = face_classifier.detectMultiScale(image, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        #detectMultiScale used to detect face at multiple scale
        #[[99, 526, 420, 205]]

        # Draw rectangles around the faces
        for (x, y, w, h) in faces:
            cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)

         # Display the captured frame with face rectangles
        cv2.imshow('Capture Frame', image)


        cropimage = None  


        # Wait for the 's' key to be pressed to capture the image
        if cv2.waitKey(1) & 0xFF == ord('s'):
            
            if len(faces) > 0:
                (x, y, w, h) = faces[0]
                cropimage = image[y:y+h, x:x+w]


            if cropimage is not None:
                # Save the captured image in the "Training_images" folder
                image_path = os.path.join(folder_path, f'{PRN}.jpg')
                cv2.imwrite(image_path, cropimage)
                print(f"Image captured and saved as {image_path}")

            

               # Insert data into table
            mycursor.execute("INSERT INTO Student_Info (Stu_name, Roll_no, PRN, Class) VALUES (%s, %s, %s, %s)", (Stu_name, rollno, PRN, class_name))
            mydb.commit()

            mycursor.execute("SELECT COUNT(*) FROM Student_Info")
            count = mycursor.fetchone()[0]

            break

    # Release the webcam and close OpenCV windows
    cap.release()
    cv2.destroyAllWindows()
    return render_template('index.html', message=count)

encodeListKnown = []
classNames=[]

@app.route('/Training_Dataset', methods=['GET'])
def Training_Dataset():
    global encodeListKnown
    global classNames
    path = 'Training_images'
    images = []
    classNames = []
    myList = os.listdir(path)
    print(myList)
    for img in myList:
        curImg = cv2.imread(f'{path}/{img}')
        images.append(curImg)
        classNames.append(os.path.splitext(img)[0])
    print(classNames)


    def findEncodings(images):
        encodeList = []

        for img in images:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encode = face_recognition.face_encodings(img)[0]
            encodeList.append(encode)
        return encodeList


    encodeListKnown = findEncodings(images)
    print('Training Dataset Completed')
    return '', 204






@app.route('/Take_Attandance', methods=['GET'])
def Take_Attandance():
    global encodeListKnown
    global classNames
    cap = cv2.VideoCapture(0)
    #cap = cv2.VideoCapture('http://192.168.75.78:8080/video')

    present_students={}


    def insert_into_database(name):
        try:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="123456",
                database="adi"
            )

            mycursor = mydb.cursor()

            sql = "INSERT INTO Attendance (name, in_time) VALUES (%s, %s)"
            val = (name, datetime.now())

            mycursor.execute(sql, val)

            mydb.commit()
            print("Record inserted successfully")
        except mysql.connector.Error as err:
            print("Error:", err)


    def update_out_time(name, out_time):
        try:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="123456",
                database="adi"
            )

            mycursor = mydb.cursor()

            sql = "UPDATE Attendance SET out_time = %s WHERE name = %s AND out_time IS NULL"
            val = (out_time, name)

            mycursor.execute(sql, val)

            mydb.commit()
            print("Out time updated successfully")
        except mysql.connector.Error as err:
            print("Error:", err)



    while True:
        success, img = cap.read()
        imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
        imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

        facesCurFrame = face_recognition.face_locations(imgS)
        #facesCurFrame [(36, 112, 79, 69)]
        encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

        for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

            print("matches",matches)
            #matches [True, False, True]

            print("faceDis",faceDis)
            #faceDis [0.35322364 0.71054379 0.55977503]

            print("faceLoc", faceLoc)
            #faceLoc (41, 93, 84, 50)

            matchIndex = np.argmin(faceDis)


            if matches[matchIndex] and any(faceDis < 0.45):
                name = classNames[matchIndex].upper()
            else:
                name = "Unknown"

            y1, x2, y2, x1 = faceLoc
            # T R B
            # 55 129 107 78
            y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
            # 220 516 428 312
            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.rectangle(img, (x1, y2-35), (x2, y2), (0, 255, 0), cv2.FILLED)

        
            if name != "Unknown":
                if name not in present_students:
                    present_students[name] = {'entered': False, 'in_time': None, 'out_time': None}
                    cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                    if present_students[name]['entered']==False:
                        present_students[name]['entered']=True
                        present_students[name]['in_time']=datetime.now()
                        cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                        insert_into_database(name) 
                else:
                    if (datetime.now() - present_students[name]['in_time']).total_seconds() > 30:
                        if present_students[name]['out_time']==None:
                            out_time=present_students[name]['out_time']=datetime.now()
                            update_out_time(name,out_time)



                cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
            else:
                cv2.putText(img, "Unknown", (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)

                
                    

        cv2.imshow('Webcam', img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

    return '', 204

        

if __name__ == '__main__':
    app.run(debug=True)























"""
204 In the context of HTTP status codes, "204 No Content" means that the server has successfully processed the request, 
but there is no content to send back in the response payload.
405 Method Not Allowed
404 means "Not Found" means that the server cannot find the requested resource."""