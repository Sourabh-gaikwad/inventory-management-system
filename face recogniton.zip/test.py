import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime

path = 'Training_images'
images = []
classNames = []
myList = os.listdir(path)
print(myList)
for cl in myList:
    curImg = cv2.imread(f'{path}/{cl}')
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])
print(classNames)


def findEncodings(images):
    encodeList = []

    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeList.append(encode)
    return encodeList


def markAttendance(name):
    with open('Attendance.csv', 'r+') as f:
        myDataList = f.readlines()

        nameList = []
        for line in myDataList:
            entry = line.split(',')
            nameList.append(entry[0])
            if name not in nameList:
                now = datetime.now()
                dtString = now.strftime('%H:%M:%S')
                f.writelines(f'\n{name},{dtString}')


encodeListKnown = findEncodings(images)
print('Encoding Complete')

#cap = cv2.VideoCapture(0)
cap = cv2.VideoCapture('http://192.0.0.4:8080/video')

while True:
    success, img = cap.read()
    imgS = cv2.resize(img, (0, 0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    facesCurFrame = face_recognition.face_locations(imgS)
    encodesCurFrame = face_recognition.face_encodings(imgS, facesCurFrame)

    for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

        print(matches)

        matchIndex = np.argmin(faceDis)
        

        if matches[matchIndex]:
            name = classNames[matchIndex].upper()
        else:
            name = "Unknown"

        y1, x2, y2, x1 = faceLoc
        y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
        cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.rectangle(img, (x1, y2-35), (x2, y2), (0, 255, 0), cv2.FILLED)
        cv2.putText(img, name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
        markAttendance(name)

    cv2.imshow('Webcam', img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()



"""

8/4/2023
from flask import Flask, render_template, request

app = Flask(__name__)

app = Flask(__name__, static_url_path='/static')




@app.route('/')
def index():
    return render_template('index.html')






@app.route('/submit', methods=['POST'])
def submit():
    # Handle the click event here
    Stu_name = request.form['input_name']
    rollno = request.form['rollno']
    PRN = request.form['PRN']
    class_name = request.form['class']
    
    # Print the input data
    print("Name:", Stu_name)
    print("Roll No:", rollno)
    print("PRN:", PRN)
    print("Class:", class_name)
    
    import mysql.connector


    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456",
        database="adi"
    )

    mycursor = mydb.cursor()

    # Execute SELECT query
    mycursor.execute("SELECT * FROM Student_Info")
    result = mycursor.fetchall()

    mycursor.execute("SELECT COUNT(*) FROM Student_Info WHERE Roll_No = %s", (rollno,))
    result = mycursor.fetchone()

    # If the primary key value already exists, return error message
    if result[0] > 0:
        return render_template('index.html', error_message=f"Error: Record with the same Roll NO => {rollno} already exists. Please recheck your Roll No & Try again")

    
    import cv2
    import os


    # Initialize the webcam
    cap = cv2.VideoCapture(0)

    # Check if the webcam is opened successfully
    if not cap.isOpened():
        print("Error: Could not open webcam")
        exit()

    # Create the "aditya" folder if it doesn't exist
    folder_path = 'Training_images'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # Counter to keep track of captured images

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()
        
        # Display the captured frame
        cv2.imshow('Capture Frame', frame)


        # Wait for the 's' key to be pressed to capture the image
        if cv2.waitKey(1) & 0xFF == ord('s'):
            # Increment the image counter
            

            # Save the captured image in the "aditya" folder
            image_path = os.path.join(folder_path, f'{PRN}.jpg')
            cv2.imwrite(image_path, frame)

            

               # Insert data into table
            mycursor.execute("INSERT INTO Student_Info (Stu_name, Roll_no, PRN, Class) VALUES (%s, %s, %s, %s)", (Stu_name, rollno, PRN, class_name))
            mydb.commit()


            print(f"Image captured and saved as {image_path}")

            break

    # Release the webcam and close OpenCV windows
    cap.release()
    cv2.destroyAllWindows()
    return '', 204
    

if __name__ == '__main__':
    app.run(debug=True)


    


    end 





@app.route('/Take_image')
def take_images():
    import cv2
    import os

    import mysql.connector


    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456",
        database="adi"
    )

    mycursor = mydb.cursor()


    # Initialize the webcam
    cap = cv2.VideoCapture(0)

    # Check if the webcam is opened successfully
    if not cap.isOpened():
        print("Error: Could not open webcam")
        exit()

    # Create the "aditya" folder if it doesn't exist
    folder_path = 'Training_images'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # Counter to keep track of captured images

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        # Display the captured frame
        cv2.imshow('Capture Frame', frame)

        # Wait for the 's' key to be pressed to capture the image
        if cv2.waitKey(1) & 0xFF == ord('s'):
            # Increment the image counter

            # Save the captured image in the "aditya" folder
            image_path = os.path.join(folder_path, f'{Stu_name}.jpg')
            cv2.imwrite(image_path, frame)

            

            sql = f"UPDATE Student_Info SET image = %s WHERE name = '{student}' AND out_time IS NULL"
            val = (image_path,)

            mycursor.execute(sql, val)
            print(f"Image captured and saved as {image_path}")

        # Break the loop if 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release the webcam and close OpenCV windows
    cap.release()
    cv2.destroyAllWindows()
    return '', 204

if __name__ == '__main__':
    app.run(debug=True)

"""